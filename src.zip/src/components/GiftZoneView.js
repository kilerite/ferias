// src/components/GiftZoneView.js

import React from "react";

const GiftZoneView = () => {
  return (
    <div>
      <h2>Gift Zone View</h2>
      <p>Estado de los ejecutivos...</p>
    </div>
  );
};

export default GiftZoneView;
